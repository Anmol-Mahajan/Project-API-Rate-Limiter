from django.contrib import admin
from .models import RateLimits

admin.site.register(RateLimits)