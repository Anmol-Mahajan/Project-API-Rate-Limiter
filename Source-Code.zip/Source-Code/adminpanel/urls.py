from django.conf.urls import url, include
from . import views

urlpatterns = [
    url('login',views.login,name="AdminPanel"),
    url('dashboard',views.dashboard,name="dashb"),
    url('logout',views.logout,name="logout")
]
