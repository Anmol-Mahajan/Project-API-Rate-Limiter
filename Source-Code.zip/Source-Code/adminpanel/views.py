from django.shortcuts import render, redirect
from django.http import HttpResponse
from .forms import Admin, UpdateLimit
from base.models import RateLimits
from django.contrib.auth.models import User
from django.contrib.auth.hashers import check_password
# Create your views here.

def login(request):

	request.session['user']=""
	context={}

	if request.method == 'POST':
		form = Admin(request.POST)

		# Fetching the form details entered by the user and validating the form
		if form.is_valid():
			username = form.cleaned_data['username']
			password = form.cleaned_data['password']
			user = User.objects.filter(username=username).values_list('password','is_superuser')
			# Checkng if even a single user exists with the given username

			if(len(user) < 1):
				context['error_message'] = "User doesn't exist"
			# [(password,),(password,)]
			# Checking the encrypted password

			elif check_password(password, user[0][0]):
				# Checking if the user is a superuser(admin)

				if user[0][1]:
					request.session['user'] = username
					return redirect('/adminpanel/dashboard')

				context['error_message'] = "Access only for admin!!"

			else: 
				context['error_message'] = "The password entered was incorrect"

	form=Admin();
	context['form'] = form
	# context=
	# {
	# 	form : //form,
	# 	error_message: "The password entered was incorrect"	/ "Access only for admin!!" / "User doesn't exist"
	# }
	return render(request, 'login.html',context)


def dashboard(request):

	if not request.session['user']:
		return redirect('/adminpanel/login')

	if request.method == 'POST':
		form = UpdateLimit(request.POST)
		# Fetching the form details entered by the user and validating the form

		if form.is_valid():
			userdetails = form.cleaned_data['user']
			rate = form.cleaned_data['rate']
			# Updating the maxrate of the user selected with the value provided by the admin
			userdetails.maxrate = rate
			userdetails.save()
			return redirect('/adminpanel/dashboard')

	details = RateLimits.objects.all()
	# Fetching the django form to be displayed to the admin to show a dropdown of the users
	form=UpdateLimit()
	return render(request, 'dashboard.html', {'form': form, 'details':details})

def logout(request):
	
	# Sesssion variable made empty to logout
	request.session['user']=""
	return redirect('/adminpanel/login')