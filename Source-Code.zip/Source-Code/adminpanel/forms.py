from django import forms
from base.models import RateLimits

class Admin(forms.Form):
	username = forms.CharField(label="Enter username",max_length=50)
	password = forms.CharField(widget=forms.PasswordInput)


class UpdateLimit(forms.Form):
	user = forms.ModelChoiceField(queryset=RateLimits.objects.all())
	rate = forms.IntegerField()